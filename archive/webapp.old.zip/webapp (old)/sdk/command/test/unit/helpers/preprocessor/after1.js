// Normal comment here
var lorem = {
    ipsum: true,
    // Nested if here
    else_here: 'ok',
    other: 'thing'
};
//<unknownTag>
var testing = 123;