/**
 * @class Kitchensink.controller.windowsphone.Main
 * @extends Kitchensink.controller.phone.Main
 *
 * This is the Main controller subclass for the 'WindowsPhone' profile. 
 *
 */
Ext.define('Kitchensink.controller.windowsphone.Main', {
    extend: 'Kitchensink.controller.phone.Main'
});